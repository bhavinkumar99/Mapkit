import UIKit
import MapKit
import CoreLocation

protocol HandleMapSearch {
    func dropPinZoomIn(placemark:MKPlacemark)
}

class ViewController: UIViewController {

    
    let locationManager = CLLocationManager()
    var locationValue : [[String:Any]] = []
    
    //let locationValue = [["name":"Rokadiya Chowki","latitude":"21.18502067989272","longitude":"72.83205692989273"],["name":"Khatodara Police Station","latitude":"21.17743382989272","longitude":"72.83259282989272"],["name":"ACP B, Divi","latitude":"21.17125867989272","longitude":"72.84366407989272"]]
    
    @IBOutlet weak var mapView: MKMapView!
   
    var resultSearchController:UISearchController? = nil
    
    var selectedPin:MKPlacemark? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        getNearbyData()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        
        for locationvalue in locationValue {
            
            let annotation = MKPointAnnotation()
            annotation.title = locationvalue["name"] as? String
            let coordinateValue = CLLocationCoordinate2D(latitude: ((locationvalue["lat"] as? NSNumber)?.doubleValue)!, longitude: ((locationvalue["lng"] as? NSNumber)?.doubleValue)!)
            annotation.coordinate = coordinateValue
            self.mapView.addAnnotation(annotation)
        }
        
        let locationSearchTable = storyboard!.instantiateViewController(withIdentifier: "LocationSearchTable") as! LocationSearchTable
        resultSearchController = UISearchController(searchResultsController: locationSearchTable)
        resultSearchController?.searchResultsUpdater = locationSearchTable

        let searchBar = resultSearchController!.searchBar
        searchBar.sizeToFit()
        searchBar.placeholder = "Search for places"
        navigationItem.titleView = resultSearchController?.searchBar

        resultSearchController?.hidesNavigationBarDuringPresentation = false
        resultSearchController?.dimsBackgroundDuringPresentation = true
        definesPresentationContext = true
        
        locationSearchTable.mapView = mapView
        
        locationSearchTable.handleMapSearchDelegate = self
    }
    func getNearbyData() {
        
        let str = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=21.1702,72.8311&radius=1500&type=police&keyword=police&key=AIzaSyBB2Pafus1Y5I9WOJKhhPz6qiPlKXYkQhQ"
        let url = URL(string: str)
        do {
            let dt = try Data(contentsOf: url!)
            do {
                let jsonData = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any]
                let results = jsonData["results"] as! [[String:Any]]
                for item in results {
                    let geometry = item["geometry"] as! [String:Any]
                    let location = geometry["location"] as! [String:Any]
                    let lat = (location["lat"] as? NSNumber)?.doubleValue
                    let lng = (location["lng"] as? NSNumber)?.doubleValue
                    let name = item["name"] as! String
                    let tempDisc = ["name":name,"lat":lat!,"lng":lng!] as [String : Any]
                    locationValue.append(tempDisc)
                }
            } catch  {
                
            }
        } catch  {
            
        }
    }

    func getDirections(){
        if let selectedPin = selectedPin {
            let mapItem = MKMapItem(placemark: selectedPin)
            let launchOptions = [MKLaunchOptionsDirectionsModeKey : MKLaunchOptionsDirectionsModeDriving]
            mapItem.openInMaps(launchOptions: launchOptions)
        }
    }
}

extension ViewController : CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error:: \(error.localizedDescription)")
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.requestLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            let span = MKCoordinateSpanMake(0.05, 0.05)
            let region = MKCoordinateRegion(center: location.coordinate, span: span)
            mapView.setRegion(region, animated: true)
        }
    }
    
    /*func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if locations.first != nil {
            print("location:: \(locations)")
        }
     
    }*/
}
extension ViewController: HandleMapSearch {
    func dropPinZoomIn(placemark:MKPlacemark){
        // cache the pin
        selectedPin = placemark
        // clear existing pins
        mapView.removeAnnotations(mapView.annotations)
        let annotation = MKPointAnnotation()
        annotation.coordinate = placemark.coordinate
        annotation.title = placemark.name
        if let city = placemark.locality,
            let state = placemark.administrativeArea {
            annotation.subtitle = "(city) (state)"
        }
        mapView.addAnnotation(annotation)
        let span = MKCoordinateSpanMake(0.05, 0.05)
        let region = MKCoordinateRegionMake(placemark.coordinate, span)
        mapView.setRegion(region, animated: true)
    }
}
extension ViewController : MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?{
        if annotation is MKUserLocation {
            //return nil so map view draws "blue dot" for standard user location
            return nil
        }
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
        pinView?.pinTintColor = UIColor.orange
        pinView?.canShowCallout = true
        let smallSquare = CGSize(width: 30, height: 30)
        let button = UIButton(frame: CGRect(origin: CGPoint.zero, size: smallSquare))
        //let button = UIButton(frame: CGRect(origin: CGPointZero, size: smallSquare))
        button.setBackgroundImage(UIImage(named: "car"), for: .normal)
        button.addTarget(self, action: #selector(ViewController.getDirections), for: .touchUpInside)
        pinView?.leftCalloutAccessoryView = button
        return pinView
    }
}


